package com.boltuix.bluetooth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat


class SmartService : Service() {

    private val CHANNEL_ID = "ForegroundServiceChannel"
    private val NOTIFICATION_ID = 112

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Perform your long-running task or background operation here

        // Return START_STICKY to ensure the service is restarted if terminated by the system
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopForeground(true)
    }

    private fun createNotification(): Notification {
        val iconColor = ContextCompat.getColor(this, R.color.custom_icon_color) // Replace with your desired color resource ID
        val builder: NotificationCompat.Builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Zig - Travel Places Safety")
            .setContentText("Welcome Board")
            .setSmallIcon(R.drawable.icon_bell)
            .setOngoing(true) // Set the notification as ongoing
        builder.setColorized(true) // Enable colorization of the small icon
        builder.color = iconColor // Set the color of the small icon

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BIBO Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = builder.build()
        startForeground(NOTIFICATION_ID, notification)
        return notification
    }
}
