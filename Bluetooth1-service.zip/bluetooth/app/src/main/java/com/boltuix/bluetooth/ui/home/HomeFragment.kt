package com.boltuix.bluetooth.ui.home

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.boltuix.bluetooth.SmartService
import com.boltuix.bluetooth.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.startService.setOnClickListener {
            startForegroundService()
        }
        binding.stopService.setOnClickListener {
            stopForegroundService()
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    private fun startForegroundService() {
        // Responsible for starting the foreground service. It checks if the service is already running and starts it using ContextCompat.startForegroundService if it is not running.
        if (!isServiceRunning()) {
            val intent = Intent(requireContext(), SmartService::class.java)
            requireContext().startService(intent)
        }
    }

    private fun stopForegroundService() {
        // Responsible for stopping the foreground service.
        if (isServiceRunning()) {
            val intent = Intent(requireContext(), SmartService::class.java)
            requireContext().stopService(intent) // If the service is running, stops it using requireContext().stopService.
        }
    }

    private fun isServiceRunning(): Boolean {
        // Checks whether the SmartService is currently running.
        val manager = requireActivity().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
            if (SmartService::class.java.name == service.service.className) {
                return true
            }
        }
        return false
    }
}
